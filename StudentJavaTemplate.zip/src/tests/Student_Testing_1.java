package tests;

import assist.Helper;
import assist.Pair;
import main.Task_1;
import main.Task_4;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Student_Testing_1 {
	
	
	static ArrayList<String[]> training_data = null;
	static ArrayList<String[]> testing_data = null;
	static {
		try {
			testing_data = Helper.readCSV("../testing_data.csv");
			training_data = Helper.readCSV("../training_data.csv");
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	/*
    This function contains one unit test for getClassesOfKNearestNeighbours.
    The function simply checks one possible behaviour, and there are many more possible. More than that
    is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    or checked.
    #
	 */
	@Test
	public void test_getClassesOfKNearestNeighbours_distance_behaviour(){
		System.out.println("\nTesting getting classes of k nearest neighbours, distance mode " +
				"***********************\n");
		int k = 3;
		List<Pair<Double, String>> measures_classes = new ArrayList<>();
		measures_classes.add(new Pair<Double,String>(Double.valueOf(0), "Female"));
		measures_classes.add(new Pair<Double,String>(Double.valueOf(0), "Male"));
		measures_classes.add(new Pair<Double,String>(Double.valueOf(1), "Female"));
		measures_classes.add(new Pair<Double,String>(Double.valueOf(1.5), "Female"));
		measures_classes.add(new Pair<Double,String>(Double.valueOf(2), "Female"));
		
		
		Map<String, Integer> outputIfDist = new HashMap<>();
		outputIfDist.put("Female",2);
		outputIfDist.put("Male",1);
		outputIfDist.put("Primate",0);
		outputIfDist.put("Rodent",0);
		outputIfDist.put("Food",0);
		
		boolean result;
		Map<String, Integer> student_result=null;
		try {
			student_result = Task_1.getClassesOfKNearestNeighbours(new ArrayList<>(measures_classes), k, false);
			result = student_result.equals(outputIfDist);
					//student_result.entrySet().containsAll(outputIfDist.entrySet()) && outputIfDist.entrySet()
			// .containsAll(student_result.entrySet());
		}
		catch(Exception e){
			System.err.println(e);
			result=false;
		}
		System.out.println(String.format(
				"getClassesOfKNearestNeighbours;Correct %s; on input %s and similarity %s. Expected %s and got %s" +
						".",result, measures_classes,false, outputIfDist,
				student_result.toString()));
		Assert.assertEquals(outputIfDist,student_result);

	}
	/*
	 This function contains one unit test for getMostCommonClass.
     The function simply checks one possible behaviour, and there are many more possible. More than that
     is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
     or checked.
     
	 */
	@Test
	public void test_getMostCommonClass() {
		System.out.println("\nTesting most common class***********************\n");
		
		Map<String, Integer> input1 = new HashMap<>();
		input1.put("Female", 2);
		input1.put("Male", 5);
		input1.put("Primate", 1);
		input1.put("Rodent", 3);
		input1.put("Food", 0);
		String answer1 = "Male";
		boolean result = false;
		
		String student_result = Task_1.getMostCommonClass(new HashMap<>(input1));
		result = student_result.equals("Male");
		System.out.println(String.format(
				"getMostCommonClass;Correct %s; on input %s. Expected %s and got %s ",
				result, input1, "Male", student_result));
		Assert.assertEquals(answer1,student_result);
	
	}
	/*
	This function contains one unit test checking if kNN output is in the right format (no guarantee
    that the content is right itself!)
    The function simply checks one possible behaviour, and there are many more possible. More than that
    is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    or checked.
	*/
	@Test
	public void test_kNNOutputFormat() {
		ArrayList<String[]> student_output = Task_1.kNN(copyList(training_data),copyList(testing_data),3,
				Task_4::computePSNRSimilarity,true,Task_1::getMostCommonClass,Task_1::getClassesOfKNearestNeighbours,
				Helper::readAndResize);
				
		boolean	result = validateDataFormat(student_output);
		System.out.println(String.format(
				"knn output format validation;Correct %s", result));
		Assert.assertTrue(result);
	}
	
	public boolean validateDataFormat(ArrayList<String[]> input){
		String[] header = new String[]{"Path", "ActualClass", "PredictedClass"};
		String[] subheader = Arrays.copyOfRange(input.get(0),0,3);
		if (!Arrays.equals(subheader, header))
			return false;
		List<String> classes = Arrays.asList(Task_1.classificationScheme);
		for(int i=1;i<input.size();i++){
			String[] row = input.get(i);
			Path filePath = Paths.get(row[0]);
			if(!Files.exists(filePath))
				return false;
			boolean isClass = classes.contains(row[1]) && classes.contains(row[2]);
			if(!isClass)
				return false;
		}
		return true;
	}
	// Just a simple copy function
	public ArrayList<String[]> copyList(ArrayList<String[]> toCopy){
		ArrayList<String[]> newList = new ArrayList<>();
		for(String[] s:toCopy)
			newList.add(s.clone());
		return newList;
	}
}
