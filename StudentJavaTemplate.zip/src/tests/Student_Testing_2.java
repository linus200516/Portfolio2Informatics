package tests;

import assist.Helper;
import main.Task_2;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;

public class Student_Testing_2 {
	int places = 7;
	
	ArrayList<String[]> classified_data = Helper.readCSV("../Extras/classified_data.csv");
	int[][] expected_matrix = new int[][]{{2, 2, 0, 1, 1}, {1, 2, 0, 0, 0}, {0, 1, 1, 0, 1}, {1, 2, 1, 3, 0}, {0, 1,
			0, 0, 1}};
	
	public Student_Testing_2() throws IOException {
	}
	
	private static double round(double value, int places) {
		if (places < 0) throw new IllegalArgumentException();
		
		BigDecimal bd = new BigDecimal(Double.toString(value));
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}
	// Just a simple copy function
	public ArrayList<String[]> copyList(ArrayList<String[]> toCopy){
		ArrayList<String[]> newList = new ArrayList<>();
		for(String[] s:toCopy)
			newList.add(s.clone());
		return newList;
	}

    // This function contains one unit test for confusionMatrix.
    // The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test1_confusionMatrix() {
		int[][] expected = expected_matrix.clone();
		int[][] student_result = Task_2.confusionMatrix(copyList(classified_data));
			//Using a helper function for equality checking, given some funky data formats sometimes
		boolean result = Arrays.deepEquals(student_result,expected);
		System.out.printf("Confusion matrix;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, Arrays.deepToString(expected),
				Arrays.deepToString(student_result));
		Assert.assertArrayEquals(student_result,expected);
	}		
	// Here we check if TPs are calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test2_computeTPs() {
		int[] student_result = Task_2.computeTPs(expected_matrix.clone());
		int[] expected = new int[]{2, 2, 1, 3, 1};
		boolean result = Arrays.equals(student_result,expected);
		System.out.printf("Computing TPs;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, Arrays.toString(expected), Arrays.toString(student_result));
		Assert.assertArrayEquals(student_result,expected);
	}
	// Here we check if FPs are calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test3_computeFPs() {
		int[] student_result = Task_2.computeFPs(expected_matrix.clone());
		int[] expected = new int[]{4, 1, 2, 4, 1};
		boolean result = Arrays.equals(student_result,expected);
		System.out.printf("Computing FPs;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, Arrays.toString(expected), Arrays.toString(student_result));
		Assert.assertArrayEquals(student_result,expected);
	}
	// Here we check if FNs are calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test4_computeFNs() {
		int[] student_result = Task_2.computeFNs(expected_matrix.clone());
		int[] expected = new int[]{2, 6, 1, 1, 2};
		boolean result = Arrays.equals(student_result,expected);
		System.out.printf("Computing FNs;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, Arrays.toString(expected), Arrays.toString(student_result));
		Assert.assertArrayEquals(student_result,expected);
	}
	// Here we check if binary precision is calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test5_computeBinaryPrecision() {
		Double student_result =  round(Task_2.computeBinaryPrecision(2, 6, 1),places);
		Double expected =  round(0.25,places);
		boolean result = student_result.equals(expected);
		System.out.printf("Computing binary precision;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, expected, student_result);
		Assert.assertEquals(student_result,expected);
	}
	// Here we check if binary recall is calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test6_computeBinaryRecall() {
		Double student_result =  round(Task_2.computeBinaryRecall(2, 6, 1),places);
		Double expected =  round(0.66666666666667,places);
		boolean result = student_result.equals(expected);
		System.out.printf("Computing binary recall;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, expected, student_result);
		Assert.assertEquals(student_result,expected);
	}
	// Here we check if binary f-measure is calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test7_computeBinaryFMeasure() {
		Double student_result =  round(Task_2.computeBinaryFMeasure(2, 6, 1),places);
		Double expected =  round(0.363636364,places);
		boolean result = student_result.equals(expected);
		System.out.printf("Computing binary f-measure;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, expected, student_result);
		Assert.assertEquals(student_result,expected);
	}
	// Here we check if macro precision is calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test8_computeMacroPrecision() {
		int[] tps = new int[]{2, 2, 1, 3, 1};
		int[] fns = new int[]{2, 6, 1, 1, 2};
		int[] fps = new int[]{4, 1, 2, 4, 1};
		int data_size = 21;
		Double student_result = round(Task_2.computeMacroPrecision(tps, fps, fns, data_size),places);
		Double expected = round(0.4523809523809524,places);
		boolean result = student_result.equals(expected);
		System.out.printf("Computing macro precision;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, expected, student_result);
		Assert.assertEquals(student_result,expected);
		
	}
	// Here we check if macro recall is calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test9_computeMacroRecall() {
		int[] tps = new int[]{2, 2, 1, 3, 1};
		int[] fns = new int[]{2, 6, 1, 1, 2};
		int[] fps = new int[]{4, 1, 2, 4, 1};
		int data_size = 21;
		Double student_result = round(Task_2.computeMacroRecall(tps, fps, fns, data_size),places);
		Double expected = round(0.4666666666666667,places);
		boolean result = student_result.equals(expected);
		System.out.printf("Computing macro recall;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, expected, student_result);
		Assert.assertEquals(student_result,expected);
		
	}
	// Here we check if macro f-measure is calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test10_computeMacroFMeasure() {
		int[] tps = new int[]{2, 2, 1, 3, 1};
		int[] fns = new int[]{2, 6, 1, 1, 2};
		int[] fps = new int[]{4, 1, 2, 4, 1};
		int data_size = 21;
		Double student_result = round(Task_2.computeMacroFMeasure(tps, fps, fns, data_size),places);
		Double expected = round(0.42181818181818176,places);
		boolean result = student_result.equals(expected);
		System.out.printf("Computing macro f-measure;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, expected, student_result);
		Assert.assertEquals(student_result,expected);
	}
	// Here we check if accuracy is calculated well
    // This function contains just one test.
	// The function simply checks one possible behaviour, and there are many more possible. More than that
    // is also supporting markers. Feel free to expand on these tests for your own purposes. This area is not marked
    // or checked.
	@Test
	public void test11_computeAccuracy() {
		int[] tps = new int[]{2, 2, 1, 3, 1};
		int[] fns = new int[]{2, 6, 1, 1, 2};
		int[] fps = new int[]{4, 1, 2, 4, 1};
		int data_size = 21;
		Double student_result = round(Task_2.computeAccuracy(tps, fps, fns, data_size),places);
		Double expected = round(0.42857142857142855,places);
		boolean result = student_result.equals(expected);
		System.out.printf("Computing accuracy;Correct %s; Expected " +
				"%s and produced %s"+
				"***********************\n%n", result, expected, student_result);
		Assert.assertEquals(student_result,expected);
												
											}
	
}
