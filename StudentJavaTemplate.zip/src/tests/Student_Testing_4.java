package tests;

import assist.Helper;
import main.Task_4;
import org.junit.Assert;
import org.junit.Test;
import org.opencv.core.Mat;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

public class Student_Testing_4 {
	int places = 7;
	
	static Mat img_red = Helper.readAndResize("../Extras/red.jpg");
	static Mat img_black = Helper.readAndResize("../Extras/black.jpg");
	static Mat img_gray = Helper.readAndResize("../Extras/gray.jpg");
	
	private static double round(double value, int places) {
		if (places < 0) throw new IllegalArgumentException();
		
		BigDecimal bd = new BigDecimal(Double.toString(value));
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}
	
	@Test
	public void test_computeCosineSimilarity() {
		System.out.println("Testing computeCosineSimilarity");
		Double val1 = round(Task_4.computeCosineSimilarity(img_red, img_gray),places);
		Double val2 = round(0.586370674634,places);
		
		boolean result = Objects.equals(val1, val2);
		
		System.out.println(String.format("Testing computeCosineSimilarity;Correct %s; on red and gray. Received" +
				" %s and expected %s."+
				"***********************\n", result, val1,val2));
		Assert.assertEquals(val2,val1);
	}

	@Test
	public void test_computeRMSEDistance() {
		System.out.println("Testing computeRMSEDistance");
		Double val1 = round(Task_4.computeRMSEDistance(img_black, img_red),places);
		Double val2 = round(147.233374839629,places);
		
		boolean result = Objects.equals(val1, val2);
		System.out.println(String.format("Testing computeRMSEDistance;Correct %s; on black and red. Received" +
				" %s and expected %s."+
				"***********************\n", result, val1,val2));
		Assert.assertEquals(val2,val1);
		
	}
	
	
}
