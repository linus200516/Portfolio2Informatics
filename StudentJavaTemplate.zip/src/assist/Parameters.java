package assist;/* Simple class written to hold program parameters It looks for the following:
      k              : the value of k neighbours
                        (needed in Tasks 1, 2, 3 and 5)
      f              : the number of folds to be used for cross-validation
                        (needed in Task 3)
      simID          : value from 1 to 5 which says what similarity should be used;
                        values from 1, 2 and 3 denote similarities from Task 1 that can be called from libraries
                        values from 4 and 5 denote similarities from Task 5 that you implement yourself
                        (needed in Tasks 1, 2, 3 and 5)
      u              : flag for how to understand the data. If true, it means data is "unseen" and
                        the classification will be written to the file. If false, it means the data is
                        for training purposes and no writing to files will happen.
                        (needed in Tasks 1, 3 and 5)
      trainingData   : csv file to be used for training the classifier, contains two columns: "Path" that denotes
                        the path to a given image file, and "Class" that gives the true class of the image
                        according to the classification scheme defined at the start of this file.
                        (needed in Tasks 1, 2, 3 and 5)
      dataToClassify : csv file formatted the same way as trainingData; it will NOT be used for training
                        the classifier, but for running and testing it
                        (needed in Tasks 1, 2, 3 and 5)
*/

import io.vavr.Function2;
import io.vavr.Function3;
import io.vavr.Function8;
import main.Task_1;
import main.Task_2;
import main.Task_3;
import main.Task_4;
import org.opencv.core.Mat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class Parameters {
    Integer k; //k for the number of neighbours
    int f; //the number of folds to consider
    
    Boolean similarityFlag;//flag telling us if a measure is a distance (value false) or similarity (value true)
    boolean u; //if we need to output the file
    String trainingDataPath; //path to the training data
    String dataToClassifyPath; //path to the data to classify
    String classifiedPath; //path to classified data

    
    String imageA;
    String imageB;
    Function2<Mat,Mat,Double> measureFunction; //the similarity to use
    
    //Staff variables, no need to use
    Function<Map<String,Integer>,String> mcc = Task_1::getMostCommonClass;
    Function3<List<Pair<Double,String>>, Integer,Boolean,Map<String,Integer> > gnc = Task_1::getClassesOfKNearestNeighbours;
    Function<String, Mat> rrf = Helper::readAndResize;
    
    Function<ArrayList<String[]>,int[][]> confusionMatrixFunction= Task_2::confusionMatrix;
    Function2<ArrayList<String[]>,Integer,List<ArrayList<String[]>>> pd = Task_3::partitionData;
    Function2<List<ArrayList<String[]>>, Integer,Map<Integer,Pair<ArrayList<String[]>,ArrayList<String[]>>>> pf =
            Task_3::preparingDataForCrossValidation;
    Function2<Map<Integer,ArrayList<String[]>>,Function2<ArrayList<String[]>,
            Function<ArrayList<String[]>,int[][]>,Map<String, Double>>,Map<String, Double>> ef = Task_3::evaluateResults;
    
    
    Function8<ArrayList<String[]>, ArrayList<String[]>, Integer,
            Function2<Mat,Mat,Double>,
            Boolean, Function<Map<String,Integer>,String>,
            Function3<List<Pair<Double,String>>, Integer,Boolean,Map<String,Integer>>,
            Function<String, Mat>,ArrayList<String[]>> knnFunction = Task_1::kNN;
    
    public Parameters(String[] args){
        if(args==null || args.length==0)
            return;
        for(String s:args){
            String[] bits = s.split("=");
            if(bits[0].equals("k"))
                this.setK(Integer.parseInt(bits[1]));
            
            if(bits[0].equals("f"))
                this.setF(Integer.parseInt(bits[1]));
            
            if(bits[0].equals("u"))
                this.setU(Boolean.parseBoolean(bits[1]));
            
            if(bits[0].equals("train"))
                this.setTrainingDataPath(bits[1]);
            
            if(bits[0].equals("toClassify"))
                this.setDataToClassifyPath(bits[1]);
            
            if(bits[0].equals("classified"))
                this.setClassifiedPath(bits[1]);
            
            if(bits[0].equals("similarityFlag"))
                this.setSimilarityFlag(Boolean.parseBoolean(bits[1]));
            
            if(bits[0].equals("imga"))
                this.setImageA(bits[1]);
            
            if(bits[0].equals("imgb"))
                this.setImageB(bits[1]);
            
            if(bits[0].equals("measureFunction")) {
                Function2<Mat,Mat, Double> fun =
                        switch (bits[1]) {
                            case "Task_4.computeCosineSimilarity":
                            case "computeCosineSimilarity":
                                yield Task_4::computeCosineSimilarity;
                            case "Task_4.computeRMSEDistance":
                            case "computeRMSEDistance":
                                yield Task_4::computeRMSEDistance;
                            case "Task_4.computePSNRSimilarity":
                            case "computePSNRSimilarity":
                                yield Task_4::computePSNRSimilarity;
                            default:
                                throw new IllegalStateException("Unexpected value: " + Integer.parseInt(bits[1]));
                        };
                this.setMeasureFunction(fun);
            }
        }
    }
    
    public Integer getK() {
        return k;
    }
    
    public void setK(Integer k) {
        this.k = k;
    }
    
    public int getF() {
        return f;
    }
    
    public void setF(int f) {
        this.f = f;
    }
    
    public boolean isU() {
        return u;
    }
    
    public void setU(boolean u) {
        this.u = u;
    }
    
    public String getTrainingDataPath() {
        return trainingDataPath;
    }
    
    public void setTrainingDataPath(String trainingDataPath) {
        this.trainingDataPath = trainingDataPath;
    }
    
    public String getDataToClassifyPath() {
        return dataToClassifyPath;
    }
    
    public void setDataToClassifyPath(String dataToClassifyPath) {
        this.dataToClassifyPath = dataToClassifyPath;
    }
    
    public Function2<Mat, Mat, Double> getMeasureFunction() {
        return measureFunction;
    }
    
    public void setMeasureFunction(Function2<Mat, Mat, Double> measureFunction) {
        this.measureFunction = measureFunction;
    }
    
    public boolean isSimilarityFlag() {
        return similarityFlag;
    }
    
    public void setSimilarityFlag(boolean similarityFlag) {
        this.similarityFlag = similarityFlag;
    }
    
    public String getClassifiedPath() {
        return classifiedPath;
    }
    
    public void setClassifiedPath(String classifiedPath) {
        this.classifiedPath = classifiedPath;
    }
    
    public Function<Map<String, Integer>, String> getMcc() {
        return mcc;
    }
    
    public void setMcc(Function<Map<String, Integer>, String> mcc) {
        this.mcc = mcc;
    }
    
    public Function3<List<Pair<Double, String>>, Integer, Boolean, Map<String, Integer>> getGnc() {
        return gnc;
    }
    
    public void setGnc(Function3<List<Pair<Double, String>>, Integer, Boolean, Map<String, Integer>> gnc) {
        this.gnc = gnc;
    }
    
    public Function<String, Mat> getRrf() {
        return rrf;
    }
    
    public void setRrf(Function<String, Mat> rrf) {
        this.rrf = rrf;
    }
    
    public String getImageA() {
        return imageA;
    }
    
    public String getImageB() {
        return imageB;
    }
    
    public void setImageA(String imageA) {
        this.imageA = imageA;
    }
    
    public void setImageB(String imageB) {
        this.imageB = imageB;
    }
    
    public Function<ArrayList<String[]>, int[][]> getConfusionMatrixFunction() {
        return confusionMatrixFunction;
    }
    
    public void setConfusionMatrixFunction(Function<ArrayList<String[]>, int[][]> confusionMatrixFunction) {
        this.confusionMatrixFunction = confusionMatrixFunction;
    }
    
    public Function8<ArrayList<String[]>, ArrayList<String[]>, Integer, Function2<Mat, Mat, Double>, Boolean, Function<Map<String, Integer>, String>, Function3<List<Pair<Double, String>>, Integer, Boolean, Map<String, Integer>>, Function<String, Mat>, ArrayList<String[]>> getKnnFunction() {
        return knnFunction;
    }
    
    public void setKnnFunction(Function8<ArrayList<String[]>, ArrayList<String[]>, Integer, Function2<Mat,
            Mat, Double>, Boolean, Function<Map<String, Integer>, String>, Function3<List<Pair<Double, String>>, Integer, Boolean, Map<String, Integer>>, Function<String, Mat>, ArrayList<String[]>> knnFunction) {
        this.knnFunction = knnFunction;
    }
    
    public Function2<ArrayList<String[]>, Integer, List<ArrayList<String[]>>> getPartitionFunction() {
        return pd;
    }
    
    public Function2<List<ArrayList<String[]>>, Integer, Map<Integer,Pair<ArrayList<String[]>, ArrayList<String[]>>>> getPrepFunction() {
        return pf;
    }
    
    public Function2<Map<Integer, ArrayList<String[]>>, Function2<ArrayList<String[]>, Function<ArrayList<String[]>,int[][]>, Map<String, Double>>, Map<String, Double>> getEvalFunction() {
        return ef;
    }
}
