package assist;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;

import java.io.*;
import java.util.ArrayList;
import java.util.Objects;

import static org.opencv.imgcodecs.Imgcodecs.imread;
import static org.opencv.imgproc.Imgproc.*;


public class Helper {
	static{ System.loadLibrary(Core.NATIVE_LIBRARY_NAME); }
	static int width = 60;
	static int height = 30;
	
	/*  This function does reading and resizing of an image located in a give path on your drive.
		DO NOT REMOVE ANY COLOURS. DO NOT MODIFY PATHS. DO NOT FLATTEN IMAGES.
		PLEASE USE DEFAULT WIDTH AND HEIGHT VALUES (see statics defined above)
    
    INPUT:  imagePath         : path to image. DO NOT MODIFY - take from the file as-is.
    OUTPUT: image             : read and resized image in RGB format, or null if the image is not found at a given
    path.
    */
	
	static public Mat readAndResize(String image_path) {
		//read image 
		
		Mat resizedImage = null;
		Mat src  =  imread(image_path);
		resizedImage = new Mat();
		cvtColor(src, resizedImage, COLOR_BGR2RGB);
		Size scaleSize = new Size(width,height);
		resize(src, resizedImage, scaleSize , 0, 0, INTER_AREA);
		return resizedImage;
		
		/*Mat image = null;
		File f = null;
		try{
			f = new File(image_path); //image file path
			image = ImageIO.read(f);
			//    System.out.println("Reading complete.");
			
			Mat resizedImage =  new Mat(width, height, Mat.TYPE_INT_RGB);
			Graphics2D graphics2D = resizedImage.createGraphics();
			graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
			graphics2D.drawImage(image, 0, 0, width, height, null);
			graphics2D.dispose();
			return resizedImage;
			
		}catch(IOException e){
			System.out.println("Error: "+e);
		}
		return image;
		 */
	}
	
	// This code has been taken from https://stackabuse.com/reading-and-writing-csvs-in-java/
	public static ArrayList<String[]> readCSV(String pathToCsv) throws IOException {
		ArrayList<String[]> answer = new ArrayList<String[]>();
		if(Objects.isNull(pathToCsv) || pathToCsv.isEmpty()){
			System.err.println("No pathToCsv provided to read");
			return answer;
		}
		File csvFile = new File(pathToCsv);
		if (csvFile.isFile()) {
			BufferedReader csvReader = new BufferedReader(new FileReader(csvFile));
			String row;
			while ((row = csvReader.readLine()) != null) {
				String[] data = row.split(",");
				answer.add(data);
				
			}
			csvReader.close();
		}
		else{
			System.err.println("File not found: " + pathToCsv + ". Please double check things!");
		}
		return answer;
	}
	// Straightforward function to write the data contained in data to a csv file at filePath
	public static void writeCSV(ArrayList<String[]> data, String filePath) throws IOException {
		FileWriter csvWriter = new FileWriter(filePath);
		
		for (String[] row : data) {
			csvWriter.append(String.join(",", row));
			csvWriter.append("\n");
		}
		
		csvWriter.flush();
		csvWriter.close();
	}
	
	
}
