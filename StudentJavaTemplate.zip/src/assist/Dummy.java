package assist;

import io.vavr.Function2;
import io.vavr.Function3;
import org.opencv.core.Mat;

import java.util.*;
import java.util.function.Function;

// If for some reason you have not completed Task 1 or Task 2 but can completed Task 3, feel free to use the following
// dummy functions.
public class Dummy {
    static int width = 60;
    static int height = 30;
    
    static String[] classificationScheme = {"Female", "Male", "Primate", "Rodent", "Food"};

    public static ArrayList<String[]> dummyKNN(ArrayList<String[]> trainingData, ArrayList<String[]> dataToClassify,
                                           Integer k,
                                          Function2<Mat,Mat,Double> measureFunction,
                                          Boolean similarityFlag, Function<Map<String,Integer>,String> mostCommonClassFunc,
                                          Function3<List<Pair<Double,String>>, Integer,Boolean,Map<String,Integer> > getKNeighboursClassesFunc,
                                          Function<String, Mat> readFunction) {
        ArrayList<String[]> classifiedData = new ArrayList<>();
        classifiedData.add(new String[]{"Path", "ActualClass", "PredictedClass"});
        for (int i = 1; i < dataToClassify.size(); i++) {
            //this is only a dummy function, we default classification to Food
            ArrayList<String> newRow = new ArrayList<>();
            Collections.addAll(newRow, dataToClassify.get(i));
            newRow.add("Food");
            classifiedData.add(newRow.toArray(new String[newRow.size()]));
        }
        System.out.println("Running dummyKNN");
        return classifiedData;
    }
    
    
    public static Map<String, Double> dummyEvaluateKNN(ArrayList<String[]> classifiedData, Function<ArrayList<String[]>,
            int[][]> confusionMatrixFunction) {
        Map<String, Double> result = new HashMap<>();
        Double precision = 1.0;
        Double recall = 1.0;
        Double fMeasure = 1.0;
        Double accuracy = 1.0;
        
        result.put("Precision", precision);
        result.put("Recall", recall);
        result.put("F-measure", fMeasure);
        result.put("Accuracy", accuracy);
        return result;
    }

}
