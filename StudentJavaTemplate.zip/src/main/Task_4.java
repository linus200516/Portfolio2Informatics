package main;


import assist.Helper;
import assist.Parameters;
import io.vavr.Function2;
import org.opencv.core.Mat;

import java.util.Objects;

import static org.opencv.core.Core.PSNR;

public class Task_4 {
	
	
	/*
 	This function computes cosine similarity between two images.
 	These images are as read from assist.Helper.readAndResize function and are in RGB format.
 	Use appropriate type transformation as needed.
 	Do not transform to grayscale. Do not remove channels.

	
	INPUT:  image1, image2    : two images to compare

	OUTPUT: value             : the similarity value between these images.

*/
	static public Double computeCosineSimilarity(Mat image1, Mat image2) {
		Double value = 0.0;

		return value;
	}
	/*
	This function computes RMSE distance between two images.
	These images are as read from assist.Helper.readAndResize function and are in RGB format.
	Use appropriate type transformation as needed.
	Do not transform to grayscale. Do not remove channels.
	INPUT:
	      image1, image2: two images to compare
	OUTPUT:
	      value : the distance value between the images (as Double)
	 */
	static public Double computeRMSEDistance(Mat image1, Mat image2) {
		Double value = 0.0;
		
		return value;
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Here is a teacher-defined similarity function you can use for Task 1
	// DO NOT OVERRIDE
	
	static public Double computePSNRSimilarity(Mat image1, Mat image2) {
		return PSNR(image1,image2);
	}
	
	    /*
    This function reads the necessary arguments (see assist.Parameters class) and based on them executes
    a give measure.

    */
	
	public static void main(String[] args) {
		// handle arguments
		Parameters params = new Parameters(args);
		Mat image1=null;
		Mat image2=null;
		Function2<Mat, Mat, Double> measure = null;
		System.out.println("Reading data from " + params.getImageA() + " and " + params.getImageB());
 		try {
			image1 = Helper.readAndResize(params.getImageA());
			image2 = Helper.readAndResize(params.getImageB());
			measure = params.getMeasureFunction();
		}catch (Exception e) {
			e.printStackTrace();
		}
		if(Objects.isNull(image1)|| Objects.isNull(image2) || Objects.isNull(params.getMeasureFunction())){
			System.err.println("Hey, some of the things for Task 4 are missing! Can't do stuff without it T_T");
			return;
		}
		double result = measure.apply(image1,image2);
		System.out.println("Measure returned "+ String.valueOf(result));
		System.out.println("Finished");
	}
	
}
