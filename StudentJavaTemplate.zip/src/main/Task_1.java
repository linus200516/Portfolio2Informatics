package main;
/*
 Task 1 [7 points out of 30] My first not-so-pretty image classifier
 Your first task is to implement the kNN classifier on your own. The template contains a range of functions
 you must implement and use appropriately for this task. The template also uses a range of functions implemented
 by the module leader to support you in this task, particularly relating to reading images and csv files accompanying
 this portfolio.
 You can start working on this task immediately. Please consult at the very least Week 2 materials.

  */


import assist.Helper;
import assist.Pair;
import assist.Parameters;
import io.vavr.Function2;
import io.vavr.Function3;
import org.opencv.core.Mat;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Function;

public class Task_1 {
    
    // Please replace with your student id!!!
    public static String studentID = "insert_id_here";
    
    // This is the classification scheme you should use for kNN
    public static String[] classificationScheme = {"Female", "Male", "Primate", "Rodent", "Food"};
    
    /*
    Given a map of classes and their occurrences, returns a class from the scheme that is most common in that
    dictionary. In case there are multiple candidates, it follows the order of classes in the scheme.
    The function returns empty string if the input dictionary is empty, does not contain any classes from the scheme,
    or if all classes in the scheme have occurrence of 0.
    
    INPUT: nearest_neighbours_classes
                              : a map that, for each and every class in the scheme, states the occurrence number
                                of this class (this particular value is calculated elsewhere). You cannot assume
                                any particular order of elements in the dictionary.
    
    OUTPUT: winner            : a class from classification scheme that is most common in the input variable.
                                In case there are multiple candidates, it follows the order of classes in the scheme.
                                Returns empty string if the input dictionary is empty, does not contain any classes
                                from the scheme, or if all classes in the scheme have occurrence of 0
    
    */
    
    public static String getMostCommonClass(Map<String, Integer> nearest_neighbours_classes) {
        String winner = "";
        
        return winner;
    }
   
    /*
    The function finds the k nearest neighbours from measures_classes, and returns a map made of classes
    and their occurrences based on these k nearest neighbours.
    
    INPUT:  measure_classes   : a list of pairs composed of a distance/similarity value
                                and class from scheme (in that order). You cannot assume that the input is
                                pre-sorted in any way.
            k                 : the value of k neighbours, greater than 0, not guaranteed to be smaller than data size.
            similarity_flag   : a boolean value stating that the measure used to produce the values above is a distance
                                (False) or a similarity (True)
    OUTPUT: nearest_neighbours_classes
                              : a map that, for each class in the scheme, states how often this class
                                was in the k nearest neighbours
    
    */
    static public Map<String,Integer> getClassesOfKNearestNeighbours(List<Pair<Double,String>> measures_classes,
                                                                     Integer k, Boolean similarityFlag) {
        Map<String,Integer> nearest_neighbours_classes = new HashMap<>();
        
        return nearest_neighbours_classes;
    }


    /*
    In this function I expect you to implement the kNN classifier. You are free to define any number of helper functions
    you need for this! You need to use all the other functions in the part of the template above.

    INPUT:      trainingData    : ArrayList that was read from the training data csv
                dataToClassify  : ArrayList that was read from the data to classify csv;
                                  this data is NOT be used for training the classifier, but for running and testing it
                k               : the value of k neighbours, greater than 0, not guaranteed to be smaller than data size.
                measureFunction : the function to be invoked to calculate similarity/distance (see Task 4 for
#                               some teacher-defined ones)
                similarityFlag  : a boolean value stating that the measure above used to produce the values is a distance
                                 (False) or a similarity (True)
         mostCommonClassFunc    : the function to be invoked to find the most common class among the neighbours
                                 (by default, it is the one from above)
     getKNeighboursClassesFunc  : the function to be invoked to find the classes of nearest neighbours
                                 (by default, it is the one from above)
             readFunction       : the function to be invoked to find to read and resize images
                                 (by default, it is the assist.Helper function)
    OUTPUT: classifiedData      : ArrayList which expands the dataToClassify with the results on how your
                                 classifier has classified a given image
    */
    
    public static ArrayList<String[]> kNN(ArrayList<String[]> trainingData, ArrayList<String[]> dataToClassify, Integer k,
                                          Function2<Mat,Mat,Double> measureFunction,
                                          Boolean similarityFlag, Function<Map<String,Integer>,String> mostCommonClassFunc,
                                          Function3<List<Pair<Double,String>>, Integer,Boolean,Map<String,Integer> > getKNeighboursClassesFunc,
                                          Function<String, Mat> readFunction) {
        ArrayList<String[]> classifiedData = new ArrayList<String[]>();
        //adds a header to the ArrayList we want to return
        classifiedData.add(new String[]{"Path", "ActualClass", "PredictedClass"});
        //    Have fun!
        
        //
        return classifiedData;
    }

    /*
    ******************************************************************************************
    * You should not need to modify things below this line - it's mostly reading and writing *
    * Be aware that error handling below is...limited.                                       *
    ******************************************************************************************

    This function reads the necessary arguments (see assist.Parameters class) and based on them executes
    the kNN classifier. If the u flag is on, the results are written to a file.

    */
    
    public static void main(String[] args) {
        // handle arguments
        Parameters params = new Parameters(args);
        ArrayList<String[]> trainingData = new ArrayList<String[]>();
        ArrayList<String[]> dataToClassify = new ArrayList<String[]>();
        
        System.out.println("Reading data from " + params.getTrainingDataPath() + " and " + params.getDataToClassifyPath());
        try {
            trainingData = Helper.readCSV(params.getTrainingDataPath());
        } catch (IOException e) {
            System.out.println("Not all of the input data is present, cannot run kNN. Exiting Task 1.");
            e.printStackTrace();
        }
        try {
            dataToClassify = Helper.readCSV(params.getDataToClassifyPath());
        } catch (IOException e) {
            System.out.println("Not all of the input data is present, cannot run kNN. Exiting Task 1.");
            e.printStackTrace();
        }
        if(Objects.isNull(dataToClassify)|| Objects.isNull(trainingData) || dataToClassify.isEmpty() ||trainingData.isEmpty() ||Objects.isNull(params.isSimilarityFlag()) || Objects.isNull(params.getMeasureFunction())){
            System.err.println("Hey, some of the things for kNN are missing! Can't do stuff without it T_T");
            return;
        }
        
        System.out.println("Running kNN");
        ArrayList<String[]> result = Task_1.kNN(trainingData, dataToClassify, params.getK(),
                params.getMeasureFunction(), params.isSimilarityFlag(), params.getMcc(),params.getGnc(),params.getRrf());
        if (params.isU()) {
            String folder = null;
            try {
                folder = Paths.get(params.getDataToClassifyPath()).getParent().toRealPath().toString();
            } catch (IOException e) {
                e.printStackTrace();
            }
            String out = folder+"/"+studentID+"_classified_data.csv";
            System.out.println("Writing data to " + out);
            try {
                Helper.writeCSV(result,out);
            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("Writing to " + out + " failed! OH NOES!");
            }
        }
        System.out.println("Finished");
    }
    
}
