package main;/*
In this file please complete the following task:

Task 3 [7 points out of 30] Cross validation

On your own, evaluate your classifier using the k-fold cross-validation technique covered in the lectures
(use the training data only). You need to implement the data partitioning and the training and testing data per
round preparation functions on your own. Output the average precisions, recalls, F-measures and accuracies resulting
from cross-validation by implementing the relevant function and incorporating what you have implemented in Task 1
and Task 2 appropriately.

You can rely on the dummy functions if you have not attempted these tasks, and during marking the code will be
invoked against teacher-implemented versions of these tasks. When invoking functions from Tasks 1 and 2, rely only on
those that were already defined in the template.

You can start working on this task immediately. Please consult at the very least Week 3 materials.
*/

import assist.Helper;
import assist.Pair;
import assist.Parameters;
import io.vavr.Function2;
import io.vavr.Function3;
import io.vavr.Function8;
import org.opencv.core.Mat;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Function;


public class Task_3 {
    
    /*
    This function takes in the data for cross evaluation and the number of partitions to split the data into.
    The input data contains the header row. The resulting partitions do not.

    INPUT: training_data     : an ArrayList array containing paths to images and actual classes (at the very least, but
                               other columns can be ignored)
                               Please refer to Task 1 for precise format description. Remember, this data contains
                               header row!
           f                 : the number of partitions to split the data into, value is greater than 0,
                               not guaranteed to be smaller than data size.
    OUTPUT: partition_list   : a list of ArrayLists, where each array represents a partition, so a subset of entries
                              of the original dataset s.t. all partitions are disjoint, roughly same size (can differ by
                               at most 1), and the union of all partitions equals the original dataset minus header row.
                              THE PARTITIONS DO NOT CONTAIN HEADER ROWS.
   */
    public static List<ArrayList<String[]>> partitionData(ArrayList<String[]> training_data, Integer f) {
        List<ArrayList<String[]>> partitions = new Vector<>();
       
        return partitions;
    }
    

    /*
    This function transforms partitions into training and testing data for each cross-validation round (there are
    as many rounds as there are partitions); in other words, we prepare the folds.
    Please remember that the training and testing data for each round must include a header at this point.

    INPUT: partition_list     : a list of ArrayLists, where each ArrayList represents a partition (see partitionData
                                function)
           f                  : the number of folds to use in cross-validation, which is the same as the number of
                                partitions the data was supposed to be split to, and the number of rounds in cross-validation.
                                Value is greater than 0.
    OUTPUT: folds             : a Map that for every the round number assigns a pair of ArrayLists, first
                                representing the training data for that round and second the testing data.
                                The round numbers start with 0. You must make sure that the training and testing data
                                are ready for use  (e.g. contain the right headers already).
     */
    
    public static Map<Integer, Pair<ArrayList<String[]>,ArrayList<String[]>>>
                preparingDataForCrossValidation(List<ArrayList<String[]>> partition_list, Integer f) {
        //This is just for error handling, if for some magical reason f and number of partitions are not the same,
        //then something must have gone wrong in the other functions and you should investigate it
        Map<Integer, Pair<ArrayList<String[]>,ArrayList<String[]>>> folds = new HashMap<>();
        if (partition_list.size() != f) {
            System.out.println("Something went really wrong! Why is the number of partitions different from f??");
            return null;
        }
        //Defining the header here for your convenience
        String[] header = new String[]{"Path", "ActualClass"};
        //Implement your code here
      
        return folds;
    }
    /*
     This function takes the classified data from each cross validation round and calculates the average precision,
     recall, accuracy and f-measure for them.
     Invoke either the Task 2 evaluation function or the dummy function here, do not code from scratch!
    
     INPUT: classifiedData      : a map that assigns to a round number the classified data computed for that cross validation round
            evaluationFunction  : the function to be invoked for the evaluation (use either the one from
                                 main.Task_2 or dummy)
     OUTPUT: map of computed average measures. You are expected to evaluate every classified data in the
                                 input map and average out these values in the usual way.
    */
    static public Map<String, Double> evaluateResults(Map<Integer,ArrayList<String[]>> classifiedData,
                                                          Function2<ArrayList<String[]>,Function<ArrayList<String[]>,int[][]>,Map<String, Double>> evaluationFunction) {
        Map<String, Double> result = new HashMap<>();
        Double precision = 0.0;
        Double recall = 0.0;
        Double fMeasure = 0.0;
        Double accuracy = 0.0;
        //Have fun with the computations !
       
        // once ready, we return the values
        result.put("Precision",precision);
        result.put("Recall", recall);
        result.put("F-measure",fMeasure);
        result.put("Accuracy", accuracy);
        return result;
    }

    /*
    In this task you are expected to perform and evaluate cross-validation on a given dataset.
    You are expected to partition the input dataset into f partitions, then arrange them into training and testing
    data for each cross validation round, and then run kNN for each round using this data and k, measure_func, and
    similarity_flag that are provided at input (see Task 1 for kNN input for more details).
    The results for each round are collected into a list and then evaluated.
    
    You are then asked to produce an output dataset which extends the original input training_data by adding
    "PredictedClass" and "FoldNumber" columns, which for each entry state what class it got predicted when it
    landed in a testing fold and what the number of that fold was (everything is in string format).
    This output dataset is then extended by two extra rows which add the average measures at the end.
    
    You are expected to invoke the Task 1 kNN classifier or the assist.Dummy classifier here, do not implement these things
    from scratch! You must use the other relevant function defined in this file.
    
     INPUT: training_data      : ArrayList that was read from the training data csv
            f                  : the number of folds, greater than 0, not guaranteed to be smaller than data size.
            k                  : the value of k neighbours, greater than 0, not guaranteed to be smaller than data size.
            measureFunction    : the function to be invoked to calculate similarity/distance (see Task 4 for
                                 some teacher-defined ones)
            similarityFlag     : a boolean value stating that the measure above used to produce the values is a distance
                                 (False) or a similarity (True)
            knnFunction        : the function to be invoked for the classification (by default, it is the one from
                                main.Task_1, but you can use dummy)
            partitionFunction  : the function used to partition the input dataset (by default, it is the one above)
            prepFunction       : the function used to transform the partitions into appropriate folds
                                (by default, it is the one above)
            evalFunction       : the function used to evaluate cross validation (by default, it is the one above)
     OUTPUT: output_dataset    : ArrayList which expands the training_data output_dataset by adding "PredictedClass"
                                 and "FoldNumber" columns, which for each entry state what class it got predicted
                                 when it landed in a testing fold and what the number of that fold was (everything is
                                 in string format). This output dataset is then extended by two extra rows which add
                                 the average measures at the end (see the h and v variables).
                                 
    */
    
    public static ArrayList<String[]> crossEvaluateKNN(ArrayList<String[]> trainingData, int f, int k,
                                                       Function2<Mat,Mat,Double> measureFunction,
                                                       boolean similarityFlag,
                                                       Function8<ArrayList<String[]>, ArrayList<String[]>, Integer,
                                                       Function2<Mat,Mat,Double>,
                                                       Boolean, Function<Map<String,Integer>,String>,
                                                       Function3<List<Pair<Double,String>>, Integer,Boolean,Map<String,Integer>>,
                                                       Function<String, Mat>,ArrayList<String[]>> knnFunction,
                                                       Function2<ArrayList<String[]>,Integer,
                                                               List<ArrayList<String[]>>> partitionFunction,
                                                       Function2<List<ArrayList<String[]>>, Integer,Map<Integer,
                                                               Pair<ArrayList<String[]>,ArrayList<String[]>>>> prepFunction,
                                                       Function2<Map<Integer,ArrayList<String[]>>,Function2<ArrayList<String[]>,
                                                               Function<ArrayList<String[]>,int[][]>,Map<String, Double>>,Map<String, Double>> evalFunction){
                                                      
        ArrayList<String[]> output_dataset = new ArrayList<>();
        output_dataset.add(new String[]{"Path", "ActualClass", "PredictedClass","FoldNumber"});
        Double avg_precision = -1.0;
        Double avg_recall = -1.0;
        Double avg_fMeasure = -1.0;
        Double avg_accuracy = -1.0;
        //Have fun with the computations !
        Map<Integer,ArrayList<String[]>> classifiedData = new HashMap<>();
        
        // The measures are now added to the end:
        output_dataset.add(new String[]{"avg_precision", String.valueOf(avg_precision)});
        output_dataset.add(new String[]{"avg_recall", String.valueOf(avg_recall)});
        output_dataset.add(new String[]{"avg_fmeasure", String.valueOf(avg_fMeasure)});
        output_dataset.add(new String[]{"avg_accuracy", String.valueOf(avg_accuracy)});
        return output_dataset;
    }

      /*
    ******************************************************************************************
    * You should not need to modify things below this line - it's mostly reading and writing *
    * Be aware that error handling below is...limited.                                       *
    ******************************************************************************************

    This function reads the necessary arguments (see assist.Parameters class) and based on them evaluates the kNN classifier.
    */
    
    public static void main(String[] args) {
        // handle arguments
        Parameters params = new Parameters(args);
        ArrayList<String[]> trainingData = new ArrayList<String[]>();
        
        System.out.println("Reading data from " + params.getTrainingDataPath());
        try {
            trainingData = Helper.readCSV(params.getTrainingDataPath());
        } catch (IOException e) {
            System.out.println("Failed to read trainingData. Exiting Task 3.");
            e.printStackTrace();
        }
        if(Objects.isNull(trainingData) ||trainingData.isEmpty()|| params.getK()<=0||Objects.isNull(params.isSimilarityFlag()) || Objects.isNull(params.getMeasureFunction()) || params.getF()<=0){
            System.err.println("Hey, some of the things for cross validating kNN are missing! Can't do stuff without it T_T");
            return;
        }
        
        System.out.println("Running cross kNN evaluation");
        ArrayList<String[]> result = Task_3.crossEvaluateKNN(trainingData,params.getF(), params.getK(),
                params.getMeasureFunction(), params.isSimilarityFlag(),  params.getKnnFunction(),
                params.getPartitionFunction(),params.getPrepFunction(),params.getEvalFunction());
        String folder = null;
        try {
            folder = Paths.get(params.getTrainingDataPath()).getParent().toRealPath().toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String out = folder+"/"+ Task_1.studentID+"_cross_validation.csv";
        System.out.println("Writing data to " + out);
        try {
            Helper.writeCSV(result,out);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Writing to " + out + " failed! OH NOES!");
        }
        System.out.println("Finished");
    }
    
}

