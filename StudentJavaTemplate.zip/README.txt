RUNNING INSTRUCTIONS
    This project relies on OpenCV 4.10.0. Please download an appropriate version from https://opencv.org/releases/ and
    modify your build path accordingly. Example of instructions of how to do that in Intellij can be found here:
    https://medium.com/@aadimator/how-to-set-up-opencv-in-intellij-idea-6eb103c1d45c

    To understand what every parameter means, please check the comment documentation in main.Task_1 and assist.Parameters class. Here are some examples of what parameters to pass to each file to run it.

    Example of params to pass to main.Task_1:
    k=2 measureFunction=Task_4.computePSNRSimilarity similarityFlag=true u=true train="..\training_data.csv" toClassify="..\testing_data.csv"

    Example of params to pass to main.Task_2:
    classified="..\classified_data.csv"

    Example of params to pass to Task 3:
    k=2 measureFunction=Task_4.computePSNRSimilarity similarityFlag=true f=3 u=true train="..\training_data.csv"

    Example of params to pass to Task 4:
    imga="../Extras/gray.jpg" imgb="../Extras/black.jpg" measureFunction=computePSNRSimilarity

ERRORS

	Please pay attention to the errors you are getting. Very often the trouble with running the program comes from the fact that
	the Images folder is not where it should be. The paths in the csv file are relative, if it is easier for you, it's fine
	to change them to absolute. Just please don't do any funny path modifications inside the code, as that will cause problems
	for me when running and marking your program.

	Please also make sure you use the correct version of Java. If the template does not compile, it means you are using
	wrong Java version. Check the assessment proforma.

PREPARING THE CODE FOR SUBMISSION

Do not forget to make your code ready to be marked on a different machine. Put the needed libraries in the lib folder.

You should submit a .zip file that contains the template files (assist.Dummy and Task files), measures.txt, and any other files you have used. If you have used different Java version than stated in the assessment proforma, include an additional .txt file saying which version was used. Do not include any .csv files or images.